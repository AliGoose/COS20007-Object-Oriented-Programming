using NUnit.Framework;
using DungeonCrawler;
using System;

namespace DungeonCrawlerTests
{
    public class GeneralTests
    {
        [SetUp]
        public void Setup()
        {
            
        }

        [Test]
        public void Test()
        {

        }
    }
}