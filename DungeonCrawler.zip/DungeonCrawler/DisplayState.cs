﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonCrawler
{
    public enum DisplayState
    {
        MainMenu,
        Shop,
        CombatSelectHero,
        CombatSelectAction,
        CombatSelectItem,
        CombatSelectAbility,
        CombatSelectTargets,
        ComatEnemyTurn
    }
}
