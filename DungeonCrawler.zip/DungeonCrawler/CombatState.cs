﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonCrawler
{
    public enum CombatState
    {
        HeroSelection,
        ActionSelection,
        AbilitySelection,
        TargetSelection,
        InventorySelection,
        RestSelection
    }
}
